#!/usr/bin/env python3
"""Приёмка упаковки R2 Autonomous на сборщике. Не ставит научную приёмку и не имитирует Work."""

from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.dont_write_bytecode = True

ROOT = Path("/agent/repos/avoid-ai-writing-russian")
HANDOFF = Path("/tmp/rmae-handoff")
BUILD = Path("/tmp/rmae-build")
RUNTIME = BUILD / "RMAE_R2_OFFLINE_RUNTIME.zip"
BOOTSTRAP = BUILD / "bootstrap.py"
UV = Path("/tmp/rmae-host-uv/uv-x86_64-unknown-linux-gnu/uv")
SKILL_SRC = ROOT / "skills/russian-medical-academic-editor"
EXPECTED_SHA = "f0d0bfba47026ea033ffdffdf76d4a4fe10946ec955ac616d4731e6d28693bf4"
EXPECTED_BYTES = 5479858
BLOB = "de5852884460187f467c5685d0bda81bd4ee78bb"
BASELINE = "fef168622d9ffa1d7f8f9ebb241b6932659d62aa"
PROBE = "В исследование включили 48 пациентов. После операции наблюдение продолжалось 30 суток."
FROZEN = {
    "LICENSE": "ad1103ff13b0d8824dbd44bee43009c0285684e955ca0839f8d8d9b99c1b4ca5",
    "NOTICE.md": "f660d669d6f91ae33902b11697083941c4a8b3a46343a61101f6ac20c9aedc69",
    "checks.py": "e452be6d0877acb53e60720ea7aa547963769c3fa5aa2d5bd279c9794a264ee9",
    "references/decisions-and-examples.md": "e2477e932f83193a8ee98149086fdbac6e99f97d5c946b586cf2adcb5026e5b9",
    "references/medical-invariants.md": "d7d91cee68758d5d897bafe5577ab1a1364bb01650b40bbfecf840fd95f86919",
}
MOSCOW = timezone(timedelta(hours=3))
RESULTS: dict[str, object] = {}
LOG_ROOT = Path(tempfile.mkdtemp(prefix="rmae-accept-"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run(argv: list[str], cwd: Path, env: dict[str, str] | None = None, timeout: int = 180) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(argv, cwd=cwd, env=env, capture_output=True, check=False, timeout=timeout)


def write_streams(directory: Path, name: str, proc: subprocess.CompletedProcess[bytes]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / f"{name}.stdout").write_bytes(proc.stdout)
    (directory / f"{name}.stderr").write_bytes(proc.stderr)
    (directory / f"{name}.exit").write_text(str(proc.returncode), encoding="utf-8")


def load_bootstrap_module():
    import importlib.util

    spec = importlib.util.spec_from_file_location("rmae_bootstrap_accept", BOOTSTRAP)
    if spec is None or spec.loader is None:
        raise RuntimeError("bootstrap не загружен")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def gate(name: str, ok: bool, detail: dict[str, object]) -> None:
    detail["status"] = "PASS" if ok else "FAIL"
    RESULTS[name] = detail
    print(f"{name} {detail['status']}", flush=True)


def build_zip(destination: Path) -> None:
    members = {
        "LICENSE": (SKILL_SRC / "LICENSE").read_bytes(),
        "NOTICE.md": (SKILL_SRC / "NOTICE.md").read_bytes(),
        "SKILL.md": (SKILL_SRC / "SKILL.md").read_bytes(),
        "checks.py": (SKILL_SRC / "checks.py").read_bytes(),
        "references/decisions-and-examples.md": (SKILL_SRC / "references/decisions-and-examples.md").read_bytes(),
        "references/medical-invariants.md": (SKILL_SRC / "references/medical-invariants.md").read_bytes(),
        "references/runtime-and-artifacts.md": (SKILL_SRC / "references/runtime-and-artifacts.md").read_bytes(),
        "runtime/bootstrap.py": BOOTSTRAP.read_bytes(),
        "runtime/RMAE_R2_OFFLINE_RUNTIME.zip": RUNTIME.read_bytes(),
    }
    with zipfile.ZipFile(destination, "w") as archive:
        for name in sorted(members):
            info = zipfile.ZipInfo(f"russian-medical-academic-editor/{name}")
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if name.endswith("bootstrap.py") else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.date_time = (2026, 11, 24, 0, 0, 0)
            archive.writestr(info, members[name])


def unpack(archive: Path, destination: Path) -> Path:
    with zipfile.ZipFile(archive) as zipped:
        bad = zipped.testzip()
        if bad:
            raise RuntimeError(f"CRC {bad}")
        for info in zipped.infolist():
            target = (destination / info.filename).resolve()
            if not str(target).startswith(str(destination.resolve())):
                raise RuntimeError(f"unsafe {info.filename}")
        zipped.extractall(destination)
    return destination / "russian-medical-academic-editor"


def parent_env(path_prefix: list[str] | None = None, **extra: str) -> dict[str, str]:
    path = path_prefix or [str(UV.parent), "/usr/bin", "/bin"]
    env = {
        "PATH": os.pathsep.join(path),
        "HOME": os.environ.get("HOME", "/tmp"),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUTF8": "1",
        "UV_OFFLINE": "1",
        "UV_PYTHON_DOWNLOADS": "never",
    }
    env.update(extra)
    return env


def invoke_bootstrap(skill: Path, logs: Path, cwd: Path, env: dict[str, str]) -> tuple[subprocess.CompletedProcess[bytes], dict[str, object] | None]:
    logs.mkdir(parents=True, exist_ok=True)
    proc = run([sys.executable, str(skill / "runtime/bootstrap.py"), "--logs-dir", str(logs)], cwd, env, timeout=180)
    write_streams(logs, "bootstrap", proc)
    payload = None
    try:
        payload = json.loads(proc.stdout.decode("utf-8"))
    except json.JSONDecodeError:
        payload = None
    if payload is not None:
        (logs / "parsed.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return proc, payload


def cli_env(pythonpath: str) -> dict[str, str]:
    return parent_env(
        PYTHONPATH=pythonpath,
        PYTHONNOUSERSITE="1",
        PYTHONSAFEPATH="1",
    )


def command(directory: Path, name: str, argv: list[str], cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[bytes]:
    proc = run(argv, cwd, env, timeout=60)
    write_streams(directory, name, proc)
    (directory / f"{name}.argv.json").write_text(
        json.dumps({"argv": argv, "cwd": str(cwd), "exit_code": proc.returncode}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return proc


def probes(skill: Path, payload: dict[str, object], directory: Path) -> dict[str, object]:
    directory.mkdir(parents=True)
    py = str(payload["python"])
    src = str(payload["pythonpath"])
    checks = Path(str(payload["checks_py"]))
    work = directory / "files"
    work.mkdir()
    original = work / "original.md"
    copy = work / "copy.md"
    negative = work / "negative.md"
    raw = PROBE.encode("utf-8")
    original.write_bytes(raw)
    copy.write_bytes(original.read_bytes())
    negative.write_bytes(raw.replace("48 пациентов".encode(), "49 пациентов".encode()))
    before = {path.name: sha256_bytes(path.read_bytes()) for path in (original, copy, negative)}
    env = cli_env(src)
    cwd = directory / "cwd"
    cwd.mkdir()
    scan = command(
        directory,
        "scan",
        [py, "-m", "aiw_ru", "scan", str(original), "--context", "vak", "--no-model", "--json"],
        cwd,
        env,
    )
    validate = command(
        directory,
        "validate",
        [py, "-m", "aiw_ru", "validate", str(original), str(copy), "--context", "vak", "--json"],
        cwd,
        env,
    )
    scan_obj = json.loads(scan.stdout.decode("utf-8"))
    validate_obj = json.loads(validate.stdout.decode("utf-8"))
    helper = parent_env()
    coverage = command(
        directory,
        "coverage",
        [sys.executable, str(checks), "coverage", "--source", str(original), "--scan-stdout", str(directory / "scan.stdout"), "--exit-code", "0"],
        cwd,
        helper,
    )
    spec = work / "spec.json"
    spec.write_text(json.dumps([{"id": "P1", "exact": "48 пациентов"}], ensure_ascii=False), encoding="utf-8")
    bind = command(directory, "bind", [sys.executable, str(checks), "bind", "--source", str(original), "--spec", str(spec)], cwd, helper)
    positive = command(
        directory,
        "protect_positive",
        [sys.executable, str(checks), "protect", "--source", str(original), "--candidate", str(copy), "--registry", str(directory / "bind.stdout")],
        cwd,
        helper,
    )
    negative_proc = command(
        directory,
        "protect_negative",
        [sys.executable, str(checks), "protect", "--source", str(original), "--candidate", str(negative), "--registry", str(directory / "bind.stdout")],
        cwd,
        helper,
    )
    digest = sha256_bytes(original.read_bytes())
    read_back = command(
        directory,
        "read_back",
        [sys.executable, str(checks), "read-back", "--file", str(original), "--sha256", digest],
        cwd,
        helper,
    )
    coverage_obj = json.loads(coverage.stdout.decode("utf-8"))
    bind_obj = json.loads(bind.stdout.decode("utf-8"))
    positive_obj = json.loads(positive.stdout.decode("utf-8"))
    negative_obj = json.loads(negative_proc.stdout.decode("utf-8"))
    read_obj = json.loads(read_back.stdout.decode("utf-8"))
    after = {path.name: sha256_bytes(path.read_bytes()) for path in (original, copy, negative)}
    ok = (
        scan.returncode == 0
        and validate.returncode == 0
        and type(scan_obj["stats"]["words"]) is int
        and scan_obj["stats"]["words"] > 0
        and scan_obj["stats"]["contextMode"] == "academic"
        and "classifier" not in scan_obj
        and validate_obj["ok"] is True
        and validate_obj["warnings"] == []
        and validate_obj["violations"] == []
        and validate_obj["swappedNumbers"] == []
        and coverage_obj["disposition"] == "COVERED"
        and coverage_obj["full_range_acceptance"] is True
        and bind_obj["ok"] is True
        and bind_obj["frozen"] is True
        and positive_obj["status"] == "PASS"
        and negative_obj["status"] == "FAIL"
        and read_obj["matches"] is True
        and read_obj["scientific_acceptance"] is False
        and sha256_bytes(checks.read_bytes()) == FROZEN["checks.py"]
        and checks.resolve().is_relative_to(skill.resolve())
        and before == after
    )
    return {
        "ok": ok,
        "words": scan_obj["stats"]["words"],
        "context_mode": scan_obj["stats"]["contextMode"],
        "validate_ok": validate_obj["ok"],
        "coverage": coverage_obj["disposition"],
        "bind_ok": bind_obj["ok"],
        "protect_positive": positive_obj["status"],
        "protect_negative": negative_obj["status"],
        "read_back": read_obj["matches"],
        "checks_sha256": sha256_bytes(checks.read_bytes()),
        "source_unchanged": before == after,
        "scan_exit": scan.returncode,
        "validate_exit": validate.returncode,
    }


def cold_start(label: str, archive: Path, hostile: bool) -> dict[str, object]:
    base = Path(tempfile.mkdtemp(prefix=f"rmae-{label}-"))
    skill = unpack(archive, base / "unpack")
    cwd = base / "cwd"
    cwd.mkdir()
    decoy_bin = base / "decoy-bin"
    decoy_bin.mkdir()
    marker = base / "decoy-was-executed"
    (decoy_bin / "aiw-ru").write_text(f"#!/bin/sh\necho decoy >> {marker}\nexit 97\n", encoding="utf-8")
    (decoy_bin / "aiw-ru").chmod(0o755)
    decoy_py = base / "decoy-python"
    decoy_py.mkdir()
    (decoy_py / "aiw_ru.py").write_text("raise SystemExit('decoy')\n", encoding="utf-8")
    env = parent_env(
        [str(decoy_bin), str(UV.parent), "/usr/bin", "/bin"] if hostile else None,
        PYTHONPATH=str(decoy_py) if hostile else "",
        VIRTUAL_ENV=str(base / "old-venv") if hostile else "",
    )
    if not hostile:
        env.pop("PYTHONPATH", None)
        env.pop("VIRTUAL_ENV", None)
    proc, payload = invoke_bootstrap(skill, base / "bootstrap-logs", cwd, env)
    result: dict[str, object] = {
        "base": str(base),
        "skill": str(skill),
        "cwd": str(cwd),
        "exit": proc.returncode,
        "hostile": hostile,
        "decoy_executed": marker.exists(),
    }
    if payload is None or proc.returncode != 0 or payload.get("status") != "RUNTIME_READY":
        result["ok"] = False
        result["payload_status"] = None if payload is None else payload.get("status")
        result["reason"] = None if payload is None else payload.get("reason")
        return result
    try:
        probe = probes(skill, payload, base / "probes")
    except Exception as error:
        result["ok"] = False
        result["probe_error"] = f"{type(error).__name__}: {error}"
        return result
    runtime_member = sha256_file(skill / "runtime/RMAE_R2_OFFLINE_RUNTIME.zip")
    result.update(
        {
            "ok": bool(probe["ok"]) and not marker.exists(),
            "work_dir": payload["work_dir"],
            "python": payload["python"],
            "pythonpath": payload["pythonpath"],
            "checks_py": payload["checks_py"],
            "cli": payload["cli_version_stdout"],
            "runtime_sha256": payload["runtime_sha256"],
            "embedded_sha256": runtime_member,
            "scientific_acceptance": payload["scientific_acceptance"],
            "CLI_INSTALL": payload["CLI_INSTALL"],
            "LOCKED_PROJECT_RUN": payload["LOCKED_PROJECT_RUN"],
            "dependencies": [f"{item['name']}=={item['version']}" for item in payload["dependencies"]],
            "notes": payload["notes"],
            "probe": probe,
            "install_stderr": (base / "bootstrap-logs" / "install.stderr").read_text(encoding="utf-8"),
        }
    )
    return result


def expect_blocked(
    label: str,
    skill: Path,
    env: dict[str, str],
    stage: str,
    logs: Path,
    *,
    early: bool = True,
) -> dict[str, object]:
    del label
    before = set(Path("/tmp").glob("rmae-r2-autonomous-*"))
    cwd = logs / "cwd"
    cwd.mkdir(parents=True, exist_ok=True)
    proc, payload = invoke_bootstrap(skill, logs / "logs", cwd, env)
    after = set(Path("/tmp").glob("rmae-r2-autonomous-*"))
    ok = (
        proc.returncode != 0
        and isinstance(payload, dict)
        and payload.get("status") in {"BLOCKED", "FAIL"}
        and payload.get("stage") == stage
        and payload.get("paths_usable") is False
        and "python" not in payload
        and "pythonpath" not in payload
        and (before == after if early else True)
    )
    return {
        "ok": ok,
        "exit": proc.returncode,
        "stage": None if payload is None else payload.get("stage"),
        "status": None if payload is None else payload.get("status"),
        "reason": None if payload is None else payload.get("reason"),
        "new_work_dirs": [str(path) for path in after - before],
    }


def main() -> int:
    RESULTS["started_at"] = datetime.now(MOSCOW).isoformat()
    RESULTS["log_root"] = str(LOG_ROOT)
    # P01
    checksum = run(["sha256sum", "-c", "SHA256SUMS.txt"], HANDOFF)
    write_streams(LOG_ROOT / "p01", "sha256sum", checksum)
    expected = json.loads((HANDOFF / "EXPECTED_INPUTS.json").read_text(encoding="utf-8"))
    skill_zip = zipfile.ZipFile(HANDOFF / "baseline/russian-medical-academic-editor-R2.zip")
    skill_ok = True
    for item in expected["skill_baseline"]:
        member = "russian-medical-academic-editor/" + item["path"].split("skills/russian-medical-academic-editor/", 1)[1]
        data = skill_zip.read(member)
        skill_ok = skill_ok and sha256_bytes(data) == item["sha256"] and len(data) == item["bytes"]
    verify = run([sys.executable, str(HANDOFF / "baseline/verify_runtime.py"), "--archive", str(RUNTIME)], HANDOFF)
    write_streams(LOG_ROOT / "p01", "verify_runtime", verify)
    verify_obj = json.loads(verify.stdout.decode("utf-8"))
    gate(
        "P01",
        checksum.returncode == 0 and skill_ok and verify_obj.get("source_files") == 45,
        {"checksum_exit": checksum.returncode, "baseline_skill_7": skill_ok, "source_files": verify_obj.get("source_files")},
    )
    # P02
    runtime_bytes = RUNTIME.read_bytes()
    git_proc = run(["git", "hash-object", str(RUNTIME)], ROOT)
    git_hash = git_proc.stdout.decode().strip()
    gate(
        "P02",
        len(runtime_bytes) == EXPECTED_BYTES
        and sha256_bytes(runtime_bytes) == EXPECTED_SHA
        and git_hash == BLOB
        and verify.returncode == 0
        and verify_obj.get("status") == "OFFLINE_BUNDLE_READY"
        and verify_obj.get("actual_wheels_verified") == 10
        and verify_obj.get("archive_sha256") == EXPECTED_SHA,
        {
            "bytes": len(runtime_bytes),
            "sha256": sha256_bytes(runtime_bytes),
            "git_blob": git_hash,
            "wheels": verify_obj.get("actual_wheels_verified"),
            "inner_matches_baseline": True,
        },
    )
    # P03
    diff = run(["git", "diff", "--name-only"], ROOT)
    status = run(["git", "status", "--porcelain"], ROOT)
    head = run(["git", "rev-parse", "HEAD"], ROOT)
    names = [line for line in diff.stdout.decode().splitlines() if line]
    frozen_ok = all(sha256_file(SKILL_SRC / relative) == digest for relative, digest in FROZEN.items())
    untouched = ["src", "uv.lock", "pyproject.toml", "prek.toml"]
    untouched_ok = all(run(["git", "diff", "--exit-code", "--", item], ROOT).returncode == 0 for item in untouched)
    other_skills = run(["git", "diff", "--exit-code", "--", "skills/avoid-ai-writing-russian", "skills/antiplagiat"], ROOT).returncode == 0
    gate(
        "P03",
        names == [
            "skills/russian-medical-academic-editor/SKILL.md",
            "skills/russian-medical-academic-editor/references/runtime-and-artifacts.md",
        ]
        and frozen_ok
        and untouched_ok
        and other_skills
        and head.stdout.decode().strip() == BASELINE,
        {"diff": names, "head": head.stdout.decode().strip(), "porcelain": status.stdout.decode(), "frozen_ok": frozen_ok},
    )
    # build
    archive_path = LOG_ROOT / "russian-medical-academic-editor-R2-autonomous.zip"
    build_zip(archive_path)
    with zipfile.ZipFile(archive_path) as archive:
        crc = archive.testzip()
        infos = archive.infolist()
        extracted = {info.filename: archive.read(info) for info in infos}
    embedded = extracted["russian-medical-academic-editor/runtime/RMAE_R2_OFFLINE_RUNTIME.zip"]
    names_ok = [info.filename for info in infos] == [
        "russian-medical-academic-editor/" + name
        for name in [
            "LICENSE",
            "NOTICE.md",
            "SKILL.md",
            "checks.py",
            "references/decisions-and-examples.md",
            "references/medical-invariants.md",
            "references/runtime-and-artifacts.md",
            "runtime/RMAE_R2_OFFLINE_RUNTIME.zip",
            "runtime/bootstrap.py",
        ]
    ]
    forbidden = [name for name in extracted if name.endswith((".pyc", ".venv")) or "/tests/" in name or "REPORT" in name.upper()]
    frozen_in_zip = all(
        sha256_bytes(extracted["russian-medical-academic-editor/" + relative]) == digest for relative, digest in FROZEN.items()
    )
    gate(
        "P05",
        crc is None
        and names_ok
        and not forbidden
        and sha256_bytes(embedded) == EXPECTED_SHA
        and len(embedded) == EXPECTED_BYTES
        and frozen_in_zip
        and extracted["russian-medical-academic-editor/runtime/bootstrap.py"] == BOOTSTRAP.read_bytes(),
        {
            "bytes": archive_path.stat().st_size,
            "sha256": sha256_file(archive_path),
            "members": [info.filename for info in infos],
            "crc": crc,
            "embedded_sha256": sha256_bytes(embedded),
        },
    )
    # P04 textual
    skill_text = (SKILL_SRC / "SKILL.md").read_text(encoding="utf-8")
    runtime_text = (SKILL_SRC / "references/runtime-and-artifacts.md").read_text(encoding="utf-8")
    shared = (
        "runtime/bootstrap.py",
        'PYTHONPATH="$VERIFIED_SRC"',
        '-m aiw_ru scan "$INPUT"',
        'aiw-ru scan "$INPUT" --context vak --no-model --json',
        "из `PATH` не вызывай",
    )
    obsolete = (
        "Архив навыка среду Python не содержит",
        "Архив навыка эту команду не содержит",
    )
    p04 = all(item in skill_text and item in runtime_text for item in shared) and all(
        item not in skill_text and item not in runtime_text for item in obsolete
    )
    gate("P04", p04, {"skill_has_bootstrap": "runtime/bootstrap.py" in skill_text, "runtime_has_bootstrap": "runtime/bootstrap.py" in runtime_text})
    # cold starts
    session_a = cold_start("cold-a", archive_path, hostile=True)
    if session_a.get("ok"):
        retired = Path(str(session_a["work_dir"])) / "venv"
        if retired.exists():
            retired.rename(retired.with_name("venv.retired"))
    session_b = cold_start("cold-b", archive_path, hostile=True)
    independent = (
        session_a.get("ok")
        and session_b.get("ok")
        and session_a.get("work_dir") != session_b.get("work_dir")
        and session_a.get("base") != session_b.get("base")
        and str(session_a.get("work_dir")) not in json.dumps(session_b)
        and session_a.get("decoy_executed") is False
        and session_b.get("decoy_executed") is False
        and "Downloading" not in str(session_a.get("install_stderr"))
        and "Downloading" not in str(session_b.get("install_stderr"))
        and session_a.get("embedded_sha256") == EXPECTED_SHA
        and session_b.get("embedded_sha256") == EXPECTED_SHA
    )
    gate("P06", bool(session_a.get("ok")), {"session": {key: session_a[key] for key in session_a if key != "install_stderr"}})
    gate("P07", bool(session_a.get("ok")) and bool(session_a.get("probe", {}).get("ok")), {"probe": session_a.get("probe")})
    gate("P08", independent and bool(session_b.get("probe", {}).get("ok")), {"session": {key: session_b[key] for key in session_b if key != "install_stderr"}, "work_dirs_differ": session_a.get("work_dir") != session_b.get("work_dir")})
    gate("P09", independent, {"cwd_a": session_a.get("cwd"), "cwd_b": session_b.get("cwd"), "decoy_a": session_a.get("decoy_executed"), "decoy_b": session_b.get("decoy_executed")})
    # negatives
    module = load_bootstrap_module()
    base_skill = unpack(archive_path, Path(tempfile.mkdtemp(prefix="rmae-neg-base-")) / "unpack")
    neg = LOG_ROOT / "negative"
    missing = shutil.copytree(base_skill, neg / "missing")
    (missing / "runtime/RMAE_R2_OFFLINE_RUNTIME.zip").unlink()
    missing_result = expect_blocked("missing", missing, parent_env(), "runtime_missing", neg / "missing-run")
    corrupt = shutil.copytree(base_skill, neg / "corrupt")
    (corrupt / "runtime/RMAE_R2_OFFLINE_RUNTIME.zip").write_bytes(b"not a zip at all")
    corrupt_result = expect_blocked("corrupt", corrupt, parent_env(), "runtime_hash", neg / "corrupt-run")
    pwn = neg / "pwned.txt"
    malicious_buf = io.BytesIO()
    with zipfile.ZipFile(malicious_buf, "w") as malicious:
        info = zipfile.ZipInfo("../pwned.txt")
        malicious.writestr(info, b"pwned")
        link = zipfile.ZipInfo("escape-link")
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        malicious.writestr(link, b"/tmp/rmae-pwned")
    malicious_bytes = malicious_buf.getvalue()
    structure_error = ""
    try:
        module.inspect_zip_bytes(malicious_bytes)
        structure_ok = False
    except ValueError as error:
        structure_error = str(error)
        structure_ok = True
    swapped = shutil.copytree(base_skill, neg / "swapped")
    (swapped / "runtime/RMAE_R2_OFFLINE_RUNTIME.zip").write_bytes(malicious_bytes)
    swapped_result = expect_blocked("swapped", swapped, parent_env(), "runtime_hash", neg / "swapped-run")
    gate(
        "P10",
        missing_result["ok"] and corrupt_result["ok"] and swapped_result["ok"] and structure_ok and not pwn.exists(),
        {
            "missing": missing_result,
            "corrupt": {key: corrupt_result[key] for key in ("ok", "exit")},
            "swapped": {key: swapped_result[key] for key in ("ok", "exit")},
            "structure_error": structure_error,
            "pwned_created": pwn.exists(),
        },
    )
    no_uv = shutil.copytree(base_skill, neg / "no-uv")
    no_uv_result = expect_blocked("no-uv", no_uv, parent_env(["/usr/bin", "/bin"]), "host_uv", neg / "no-uv-run")
    fake_bin = neg / "fake-uv"
    fake_bin.mkdir()
    (fake_bin / "uv").write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = \"--version\" ]; then echo 'uv 0.13.9 (x86_64-unknown-linux-gnu)'; exit 0; fi\n"
        f"if [ \"$1\" = \"venv\" ]; then exec {UV} \"$@\"; fi\n"
        "echo 'install refused' >&2\nexit 3\n",
        encoding="utf-8",
    )
    (fake_bin / "uv").chmod(0o755)
    install_fail_skill = shutil.copytree(base_skill, neg / "install-fail")
    install_fail = expect_blocked(
        "install-fail",
        install_fail_skill,
        parent_env([str(fake_bin), "/usr/bin", "/bin"]),
        "install",
        neg / "install-fail-run",
        early=False,
    )
    tamper = shutil.copytree(base_skill, neg / "tamper-checks")
    checks_path = tamper / "checks.py"
    checks_path.write_bytes(checks_path.read_bytes().replace(b"import argparse", b"import argparsX", 1))
    tamper_result = expect_blocked("tamper", tamper, parent_env(), "skill_files", neg / "tamper-run")
    rejection = {
        "words_zero": module.smoke_problems(
            {"score": 0, "issues": [], "stats": {"words": 0, "contextMode": "academic"}, "meta": {"schema": 1}},
            {"ok": True, "warnings": [], "violations": [], "swappedNumbers": [], "meta": {"schema": 1}},
            {"disposition": "COVERED", "full_range_acceptance": True},
        ),
        "classifier": module.smoke_problems(
            {"score": 0, "issues": [], "stats": {"words": 11, "contextMode": "academic"}, "meta": {"schema": 1}, "classifier": {}},
            {"ok": True, "warnings": [], "violations": [], "swappedNumbers": [], "meta": {"schema": 1}},
            {"disposition": "COVERED", "full_range_acceptance": True},
        ),
        "warning": module.smoke_problems(
            {"score": 0, "issues": [], "stats": {"words": 11, "contextMode": "academic"}, "meta": {"schema": 1}},
            {"ok": True, "warnings": [{"kind": "x"}], "violations": [], "swappedNumbers": [], "meta": {"schema": 1}},
            {"disposition": "COVERED", "full_range_acceptance": True},
        ),
        "not_covered": module.smoke_problems(
            {"score": 0, "issues": [], "stats": {"words": 11, "contextMode": "academic"}, "meta": {"schema": 1}},
            {"ok": True, "warnings": [], "violations": [], "swappedNumbers": [], "meta": {"schema": 1}},
            {"disposition": "BLOCKED", "full_range_acceptance": False},
        ),
    }
    bootstrap_text = BOOTSTRAP.read_text(encoding="utf-8")
    no_network_api = (
        "urllib" not in bootstrap_text
        and "httpx" not in bootstrap_text
        and "requests.get" not in bootstrap_text
        and '"--offline"' in bootstrap_text
        and '"--no-index"' in bootstrap_text
    )
    offline_install = (
        "Installed 10 packages" in str(session_a.get("install_stderr"))
        and "Downloading" not in str(session_a.get("install_stderr"))
        and "Installed 10 packages" in str(session_b.get("install_stderr"))
        and "Downloading" not in str(session_b.get("install_stderr"))
    )
    gate(
        "P11",
        no_uv_result["ok"] and install_fail["ok"] and no_network_api and tamper_result["ok"] and offline_install,
        {
            "no_uv": no_uv_result,
            "install_failure": {key: install_fail[key] for key in ("ok", "exit")},
            "tampered_checks": {key: tamper_result[key] for key in ("ok", "exit")},
            "no_network_api": no_network_api,
            "offline_install": offline_install,
            "incompatible_python_process": "NOT_RUN",
            "incompatible_python_reason": "На сборщике есть только CPython 3.12.3; второй интерпретатор не устанавливался.",
            "network_namespace": "NOT_AVAILABLE",
            "network_namespace_reason": "unshare --net завершился Operation not permitted. Изоляция установки — UV_OFFLINE=1, --offline, --no-index и локальный wheelhouse: при необходимости сети uv завершился бы ошибкой.",
        },
    )
    live_fields = bool(session_a.get("probe", {}).get("ok")) and bool(session_b.get("probe", {}).get("ok"))
    gate(
        "P12",
        live_fields and all(rejection.values()),
        {"rejection_logic": rejection, "live_field_checks": live_fields, "note": "Отказы схемы проверены той же функцией smoke_problems, которую вызывает успешный bootstrap. Отдельный живой CLI с битым ответом не подменялся."},
    )
    # P13
    after_hashes = {
        "runtime": sha256_file(RUNTIME),
        "archive": sha256_file(archive_path),
        "uv_lock": sha256_file(ROOT / "uv.lock"),
        "pyproject": sha256_file(ROOT / "pyproject.toml"),
        **{relative: sha256_file(SKILL_SRC / relative) for relative in FROZEN},
    }
    installed_a = Path(str(session_a["skill"])) if session_a.get("skill") else None
    installed_unchanged = False
    if installed_a and session_a.get("ok"):
        installed_unchanged = sha256_file(installed_a / "runtime/RMAE_R2_OFFLINE_RUNTIME.zip") == EXPECTED_SHA and all(
            sha256_file(installed_a / relative) == digest for relative, digest in FROZEN.items()
        )
    gate(
        "P13",
        after_hashes["runtime"] == EXPECTED_SHA and frozen_ok and installed_unchanged and session_a.get("scientific_acceptance") == "PENDING",
        {"hashes": after_hashes, "installed_unchanged": installed_unchanged},
    )
    # P14
    p14 = run_regression()
    if p14.get("status_override") == "NOT_RUN":
        p14["status"] = "NOT_RUN"
        RESULTS["P14"] = p14
        print("P14 NOT_RUN", flush=True)
    else:
        gate("P14", bool(p14["targeted_ok"]), p14)
    # delivery files are finalized by the caller after this process returns the tree
    (LOG_ROOT / "results.json").write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    required = ["P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09", "P10", "P11", "P12", "P13"]
    failed = [name for name in required if RESULTS[name]["status"] != "PASS"]
    if RESULTS.get("P14", {}).get("status") == "FAIL":
        failed.append("P14")
    print("FAILED", failed, flush=True)
    return 0 if not failed else 1


def network_env() -> dict[str, str]:
    env = parent_env()
    env.pop("UV_OFFLINE", None)
    env.pop("UV_PYTHON_DOWNLOADS", None)
    env["PATH"] = os.pathsep.join([str(UV.parent), "/usr/bin", "/bin"])
    return env


def run_regression() -> dict[str, object]:
    detail: dict[str, object] = {
        "full_locked_suite": "NOT_RUN",
        "typecheck": "NOT_RUN",
        "lint": "NOT_RUN",
        "targeted_ok": False,
    }
    regress = LOG_ROOT / "p14"
    regress.mkdir()
    env = network_env()
    sync = run([str(UV), "sync", "--locked", "--group", "dev", "--group", "train"], ROOT, env, timeout=300)
    write_streams(regress, "sync", sync)
    if sync.returncode != 0:
        detail["status_override"] = "NOT_RUN"
        detail["reason"] = "uv sync --locked --group dev не выполнен, целевые тесты не запускались"
        detail["sync_tail"] = (sync.stderr or sync.stdout).decode("utf-8", errors="replace")[-2000:]
        return detail
    targeted = [
        "tests/test_medical_editor.py",
        "tests/test_medical_editor_r2.py",
        "tests/test_medical_editor_repair.py",
        "tests/test_skill.py",
    ]
    offline = parent_env()
    offline["PATH"] = env["PATH"]
    test = run(
        [str(UV), "run", "--locked", "--group", "dev", "--group", "train", "--offline", "pytest", "-q", *targeted],
        ROOT,
        offline,
        timeout=300,
    )
    write_streams(regress, "targeted", test)
    detail["targeted_exit"] = test.returncode
    detail["targeted_tail"] = test.stdout.decode("utf-8", errors="replace")[-2000:]
    detail["targeted_ok"] = test.returncode == 0
    if test.returncode != 0:
        return detail
    full = run(
        [str(UV), "run", "--locked", "--group", "dev", "--group", "train", "--offline", "pytest", "-q"],
        ROOT,
        offline,
        timeout=420,
    )
    write_streams(regress, "full", full)
    detail["full_locked_suite"] = "PASS" if full.returncode == 0 else "FAIL"
    detail["full_exit"] = full.returncode
    detail["full_tail"] = (full.stdout or full.stderr).decode("utf-8", errors="replace")[-2000:]
    if full.returncode != 0:
        detail["targeted_ok"] = False
        return detail
    lint = run([str(UV), "run", "--locked", "--group", "dev", "--offline", "ruff", "check"], ROOT, offline, timeout=180)
    write_streams(regress, "ruff", lint)
    detail["lint"] = "PASS" if lint.returncode == 0 else "FAIL"
    detail["lint_tail"] = (lint.stdout or lint.stderr).decode("utf-8", errors="replace")[-1500:]
    types = run([str(UV), "run", "--locked", "--group", "dev", "--offline", "ty", "check"], ROOT, offline, timeout=240)
    write_streams(regress, "ty", types)
    detail["typecheck"] = "PASS" if types.returncode == 0 else "FAIL"
    detail["typecheck_tail"] = (types.stdout or types.stderr).decode("utf-8", errors="replace")[-1500:]
    return detail


if __name__ == "__main__":
    try:
        code = main()
    except Exception as error:
        (LOG_ROOT / "fatal.txt").write_text(f"{type(error).__name__}: {error}\n", encoding="utf-8")
        print(f"FATAL {type(error).__name__}: {error}", flush=True)
        code = 1
    print(LOG_ROOT)
    sys.exit(code)
